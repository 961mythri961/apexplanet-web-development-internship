# Responsive Web Development Portfolio — Internship Capstone

**Student:** Bavanasi Mythri  
**College:** Mohan Babu University, School of Computing  
**Internship context in report:** Web Development, ApexPlanet Software Pvt Ltd  
**Faculty supervisor listed in report:** I. Sravani, Assistant Professor, CSE

> **Project provenance:** This repository is a reconstructed capstone created to match the project description in the internship presentation. It is not proof that this exact source code was submitted to or produced during the original internship. Before presenting it as internship work, compare it with your original files and describe it accurately to your mentor.

## Overview

A responsive, multi-section portfolio-style website built with HTML5, CSS3, and vanilla JavaScript. It contains the four sections described in the presentation: **Home, About, Projects, and Contact**.

## Features

- Responsive layouts for desktop, tablet, and mobile screens
- Mobile navigation menu with accessible expanded state
- Active navigation link based on the visible section
- About section with a learning toolkit
- Project showcase cards
- Contact form with required-field and email-format validation
- Clear success/error messages for the demo form
- Semantic HTML, keyboard focus styles, and reduced-motion support
- No external JavaScript libraries or build tools required

## Technology stack

- **HTML5:** semantic page structure
- **CSS3:** Flexbox/Grid, media queries, custom properties, responsive styling
- **JavaScript (ES6):** DOM manipulation, events, section observer, form validation
- **Git/GitHub:** source-code version control and repository hosting
- **GitHub Pages:** optional static-site deployment
- **Visual Studio Code:** suggested editor

## Project structure

```text
apexplanet-web-development-internship/
├── index.html
├── style.css
├── script.js
└── README.md
```

## Run locally

1. Download or clone this repository.
2. Open `index.html` in a modern browser, or open the folder in Visual Studio Code and use a local preview extension.
3. Test the navigation at mobile widths and try the contact form with missing fields and an invalid email.

No `npm install` or compilation step is needed.

## Deploy using GitHub Pages

1. Push these files to a GitHub repository.
2. Open **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select branch `main` and folder `/(root)`, then save.
5. Wait for the deployment status and open the URL shown on the Pages settings screen.

## Testing checklist

- [ ] Navigation links scroll to the right sections.
- [ ] Mobile menu opens and closes.
- [ ] Layout remains readable on mobile, tablet, and desktop.
- [ ] Contact form shows an error if any required field is empty.
- [ ] Contact form rejects an invalid email address.
- [ ] Valid form input displays a confirmation message.
- [ ] The form clearly states that no message is sent to a server.
- [ ] GitHub Pages site loads without missing CSS or JavaScript.

## Important notes before submission

- Replace or remove any personal details you do not want to publish.
- The contact form is front-end-only; it does not send or store messages.
- The dashboard and contact-form cards in the Projects section are practice concepts, not claims of separate completed internship projects.
- Do not claim original internship authorship for this reconstructed repository unless you verify that it matches the work you actually submitted.
