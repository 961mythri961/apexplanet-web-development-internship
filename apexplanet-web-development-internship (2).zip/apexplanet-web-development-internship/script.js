const menuToggle = document.querySelector("#menuToggle");
const navLinks = document.querySelector("#navLinks");
const navItems = document.querySelectorAll(".nav-link");
const contactForm = document.querySelector("#contactForm");
const formError = document.querySelector("#formError");
const formSuccess = document.querySelector("#formSuccess");

document.querySelector("#year").textContent = new Date().getFullYear();

// Mobile navigation: open/close the menu and update its accessibility state.
menuToggle.addEventListener("click", () => {
  const isOpen = navLinks.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
  menuToggle.setAttribute("aria-label", isOpen ? "Close navigation menu" : "Open navigation menu");
});

navItems.forEach((item) => {
  item.addEventListener("click", () => {
    navLinks.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
    menuToggle.setAttribute("aria-label", "Open navigation menu");
  });
});

// Highlight the navigation link for the section currently in view.
const sections = document.querySelectorAll("main section[id]");
const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (!entry.isIntersecting) return;
    navItems.forEach((link) => {
      const active = link.getAttribute("href") === `#${entry.target.id}`;
      link.classList.toggle("active", active);
    });
  });
}, { rootMargin: "-35% 0px -55% 0px" });

sections.forEach((section) => observer.observe(section));

// Client-side validation only. This form does not transmit or save user data.
contactForm.addEventListener("submit", (event) => {
  event.preventDefault();
  formError.textContent = "";
  formSuccess.textContent = "";

  const name = document.querySelector("#name");
  const email = document.querySelector("#email");
  const message = document.querySelector("#message");
  const fields = [name, email, message];

  fields.forEach((field) => field.setAttribute("aria-invalid", "false"));

  const invalid = fields.find((field) => !field.value.trim());
  if (invalid) {
    invalid.setAttribute("aria-invalid", "true");
    formError.textContent = "Please complete all required fields.";
    invalid.focus();
    return;
  }

  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailPattern.test(email.value.trim())) {
    email.setAttribute("aria-invalid", "true");
    formError.textContent = "Please enter a valid email address.";
    email.focus();
    return;
  }

  formSuccess.textContent = `Thanks, ${name.value.trim()}! The form passed validation. This demo does not send your message.`;
  contactForm.reset();
});
